//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-S7tL3tmS.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DYQET9gP.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DYQET9gP.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-VcK2nNrU.js"]
	}
} });
//#endregion
export { tsrStartManifest };
