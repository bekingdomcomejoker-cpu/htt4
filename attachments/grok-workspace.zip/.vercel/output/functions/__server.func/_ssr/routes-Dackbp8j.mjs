import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, r as Slot, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Root } from "../_libs/@radix-ui/react-label+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as object, c as union, i as number, n as boolean, o as record, s as string, t as _null } from "../_libs/zod.mjs";
import { a as Radio, c as Folder, d as Activity, i as SquareTerminal, l as ChevronRight, n as Unplug, o as Lock, s as LoaderCircle, t as Wifi, u as BatteryCharging } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Route, r as DEFAULT_MCP_URL } from "./router-Cxgor64A.mjs";
import { n as useQuery, r as QueryClientProvider, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dackbp8j.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium tracking-wide", {
	variants: { variant: {
		default: "bg-accent text-accent-foreground",
		live: "bg-live/15 text-live",
		warn: "bg-warn/15 text-warn",
		mute: "bg-muted text-muted-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,box-shadow] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40 [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow-border hover:opacity-90",
			secondary: "bg-secondary text-secondary-foreground shadow-border hover:bg-accent",
			outline: "bg-transparent text-foreground shadow-border hover:bg-accent",
			ghost: "text-muted-foreground hover:bg-accent hover:text-foreground",
			destructive: "bg-destructive text-primary-foreground hover:opacity-90"
		},
		size: {
			default: "h-11 min-h-11 px-4",
			sm: "h-9 min-h-9 px-3 text-xs",
			lg: "h-12 min-h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Card = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("rounded-xl bg-card text-card-foreground shadow-border", className),
	...props
}));
Card.displayName = "Card";
var CardHeader = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("flex flex-col gap-1 p-5", className),
	...props
}));
CardHeader.displayName = "CardHeader";
var CardTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
	ref,
	className: cn("text-lg font-medium tracking-tight text-balance", className),
	...props
}));
CardTitle.displayName = "CardTitle";
var CardDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
	ref,
	className: cn("text-sm text-muted-foreground text-pretty", className),
	...props
}));
CardDescription.displayName = "CardDescription";
var CardContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("p-5 pt-0", className),
	...props
}));
CardContent.displayName = "CardContent";
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
	type,
	className: cn("flex h-11 w-full rounded-md border border-border bg-input px-3 text-sm text-foreground shadow-none transition-[box-shadow,border-color] duration-[var(--motion-quick)] placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-40", className),
	ref,
	...props
}));
Input.displayName = "Input";
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn("text-sm font-medium text-foreground", className),
	...props
}));
Label.displayName = Root.displayName;
var Tabs = Root2;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
	ref,
	className: cn("flex h-11 w-full items-center gap-1 overflow-x-auto rounded-lg bg-muted p-1 text-muted-foreground", className),
	...props
}));
TabsList.displayName = List.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
	ref,
	className: cn("inline-flex h-9 min-h-9 flex-1 items-center justify-center whitespace-nowrap rounded-md px-3 text-sm font-medium transition-[background-color,color] duration-[var(--motion-quick)] data-[state=active]:bg-card data-[state=active]:text-foreground data-[state=active]:shadow-border focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", className),
	...props
}));
TabsTrigger.displayName = Trigger.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
	ref,
	className: cn("mt-4 focus-visible:outline-none", className),
	...props
}));
TabsContent.displayName = Content.displayName;
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
	className: cn("flex min-h-28 w-full rounded-md border border-border bg-input px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-40", className),
	ref,
	...props
}));
Textarea.displayName = "Textarea";
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var creds = {
	url: string().url(),
	apiKey: string().min(8)
};
var jsonScalar = union([
	string(),
	number(),
	boolean(),
	_null()
]);
var probeMcpHealth = createServerFn({ method: "POST" }).validator(object({ url: string().url() })).handler(createSsrRpc("97f5bb22daad0d8fbbdc08f9fefc383669f827ef8e7e8f92e7a3097af065da18"));
var listMcpTools = createServerFn({ method: "POST" }).validator(object(creds)).handler(createSsrRpc("fa8e5cfdbb9f0d98de7951d42c5d501396053ad659094f9b193013667d56c85c"));
var callMcpTool = createServerFn({ method: "POST" }).validator(object({
	...creds,
	name: string().min(1),
	args: record(string(), jsonScalar).optional(),
	timeoutMs: number().int().min(1e3).max(12e4).optional()
})).handler(createSsrRpc("1799d2095a177b536c877de2f355dbc1ef57bebf9d22ee3ff19363bca7db8ff5"));
var useOmegaStore = create()(persist((set) => ({
	url: DEFAULT_MCP_URL,
	apiKey: "",
	unlocked: false,
	history: [],
	cwd: ".",
	setUrl: (url) => set({ url }),
	setApiKey: (apiKey) => set({ apiKey }),
	unlock: (url, apiKey) => set({
		url,
		apiKey,
		unlocked: true
	}),
	lock: () => set({
		unlocked: false,
		apiKey: "",
		history: []
	}),
	pushHistory: (entry) => set((state) => ({ history: [{
		...entry,
		id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
		at: Date.now()
	}, ...state.history].slice(0, 40) })),
	setCwd: (cwd) => set({ cwd })
}), {
	name: "omega-pool-session",
	storage: createJSONStorage(() => sessionStorage),
	skipHydration: true,
	partialize: (state) => ({
		url: state.url,
		apiKey: state.apiKey,
		unlocked: state.unlocked,
		cwd: state.cwd
	})
}));
function parseMaybeJson(text) {
	const trimmed = text.trim();
	if (!trimmed) return null;
	try {
		return JSON.parse(trimmed);
	} catch {
		return null;
	}
}
function parseBattery(text) {
	const parsed = parseMaybeJson(text);
	if (!parsed || typeof parsed !== "object") return null;
	const rec = parsed;
	return {
		health: typeof rec.health === "string" ? rec.health : void 0,
		status: typeof rec.status === "string" ? rec.status : void 0,
		plugged: typeof rec.plugged === "string" ? rec.plugged : void 0,
		temperature: typeof rec.temperature === "number" ? rec.temperature : void 0,
		voltage: typeof rec.voltage === "number" ? rec.voltage : void 0,
		percentage: typeof rec.percentage === "number" ? rec.percentage : void 0,
		level: typeof rec.level === "number" ? rec.level : void 0
	};
}
function parseConnectors(text) {
	return parseMaybeJson(text)?.connectors ?? [];
}
function OmegaConsole({ joinKey }) {
	const unlocked = useOmegaStore((s) => s.unlocked);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const done = () => setHydrated(true);
		const persistApi = useOmegaStore.persist;
		Promise.resolve(persistApi.rehydrate()).finally(done);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated || !joinKey) return;
		const current = useOmegaStore.getState();
		current.unlock(current.url || "https://direction-egotistic-citric.ngrok-free.dev", joinKey);
	}, [hydrated, joinKey]);
	if (!hydrated || !unlocked) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UnlockGate, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BridgeWorkspace, {});
}
function UnlockGate() {
	const url = useOmegaStore((s) => s.url);
	const setUrl = useOmegaStore((s) => s.setUrl);
	const unlock = useOmegaStore((s) => s.unlock);
	const [key, setKey] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const health = useQuery({
		queryKey: ["mcp-health", url],
		queryFn: () => probeMcpHealth({ data: { url } }),
		refetchInterval: 12e3
	});
	async function onJoin(event) {
		event.preventDefault();
		setBusy(true);
		try {
			const result = await listMcpTools({ data: {
				url,
				apiKey: key.trim()
			} });
			unlock(url, key.trim());
			toast.success(`Joined ${result.tools.length} tools`);
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Join failed");
		} finally {
			setBusy(false);
		}
	}
	const live = health.data?.ok === true;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh max-w-lg flex-col justify-center gap-8 px-5 py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
					children: "Termux control plane"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-4xl font-medium tracking-tight",
					children: "OMEGA Pool"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-md text-sm leading-relaxed text-muted-foreground",
					children: "This console talks to the phone-local MCP over the ngrok tunnel. There is no inbound VPS — the bridge stays on Termux; we join it as a client."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "rounded-xl p-1",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-card p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-5 flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Bridge"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Health does not need a key. Tools do."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: live ? "live" : "warn",
						children: live ? "Live" : health.isLoading ? "Checking" : "Offline"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "space-y-4",
					onSubmit: onJoin,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "mcp-url",
								children: "MCP URL"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "mcp-url",
								value: url,
								onChange: (e) => setUrl(e.target.value),
								autoComplete: "off",
								spellCheck: false
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "mcp-key",
								children: "X-API-Key"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "mcp-key",
								type: "password",
								value: key,
								onChange: (e) => setKey(e.target.value),
								autoComplete: "off",
								spellCheck: false,
								placeholder: "Termux MCP token"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "submit",
							className: "w-full",
							disabled: busy || key.length < 8,
							children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4" }), "Join bridge"]
						})
					]
				})]
			})
		})]
	});
}
function BridgeWorkspace() {
	const url = useOmegaStore((s) => s.url);
	const apiKey = useOmegaStore((s) => s.apiKey);
	const lock = useOmegaStore((s) => s.lock);
	const creds = (0, import_react.useMemo)(() => ({
		url,
		apiKey
	}), [url, apiKey]);
	const health = useQuery({
		queryKey: ["mcp-health", url],
		queryFn: () => probeMcpHealth({ data: { url } }),
		refetchInterval: 1e4
	});
	const tools = useQuery({
		queryKey: [
			"mcp-tools",
			url,
			apiKey
		],
		queryFn: () => listMcpTools({ data: creds })
	});
	const battery = useQuery({
		queryKey: [
			"mcp-battery",
			url,
			apiKey
		],
		queryFn: async () => {
			return parseBattery((await callMcpTool({ data: {
				...creds,
				name: "battery_status",
				timeoutMs: 15e3
			} })).text);
		},
		refetchInterval: 3e4
	});
	const live = health.data?.ok === true;
	const pct = Number(battery.data?.percentage ?? battery.data?.level ?? NaN);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "sticky top-0 z-20 border-b border-border bg-background/90 backdrop-blur",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
						children: "v2.4 backup relay"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "truncate text-lg font-medium tracking-tight",
						children: "OMEGA Pool"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: live ? "live" : "warn",
						children: live ? "Live" : "Offline"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: () => lock(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Unplug, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: "Disconnect"
						})]
					})]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-6xl space-y-6 px-4 py-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid grid-cols-2 gap-3 md:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Bridge",
						value: live ? "Connected" : "Down",
						hint: health.data?.service || "omega-termux-mcp",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Tools",
						value: String(tools.data?.tools.length ?? "—"),
						hint: "streamable-http :8787",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Battery",
						value: Number.isFinite(pct) ? `${pct}%` : "—",
						hint: battery.data ? `${String(battery.data.status ?? "unknown")} · ${String(battery.data.plugged ?? "unplugged")}` : "Android battery",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BatteryCharging, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Auth",
						value: "X-API-Key",
						hint: "Bearer is rejected by this bridge",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4" })
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				defaultValue: "shell",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "shell",
							children: "Shell"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "files",
							children: "Files"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "network",
							children: "Network"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "tools",
							children: "Tools"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "shell",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShellPanel, { creds })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "files",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilesPanel, { creds })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "network",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NetworkPanel, {
							creds,
							battery: battery.data
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "tools",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolsPanel, {
							creds,
							tools: tools.data?.tools ?? []
						})
					})
				]
			})]
		})]
	});
}
function StatCard({ label, value, hint, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
		className: "rounded-xl p-1",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-lg p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-medium uppercase tracking-wide",
						children: label
					}), icon]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-2xl font-medium tabular-nums tracking-tight",
					children: value
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 truncate text-xs text-muted-foreground",
					children: hint
				})
			]
		})
	});
}
function ShellPanel({ creds }) {
	const history = useOmegaStore((s) => s.history);
	const pushHistory = useOmegaStore((s) => s.pushHistory);
	const [command, setCommand] = (0, import_react.useState)("uname -a");
	const outputRef = (0, import_react.useRef)(null);
	const run = useMutation({
		mutationFn: (cmd) => callMcpTool({ data: {
			...creds,
			name: "termux_exec",
			args: {
				command: cmd,
				timeout: 30
			},
			timeoutMs: 4e4
		} }),
		onSuccess: (result, cmd) => {
			pushHistory({
				command: cmd,
				output: result.text,
				ok: result.ok
			});
			if (!result.ok) toast.error("Command returned an error");
		},
		onError: (error) => {
			toast.error(error instanceof Error ? error.message : "Exec failed");
		}
	});
	(0, import_react.useEffect)(() => {
		outputRef.current?.scrollTo({ top: 0 });
	}, [history[0]?.id]);
	const latest = history[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
		className: "rounded-xl p-1",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-lg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
				className: "pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
					className: "flex items-center gap-2 text-base",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquareTerminal, { className: "size-4" }), "termux_exec"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Isolated shell on the phone. Catastrophic commands are blocked here." })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						ref: outputRef,
						className: "max-h-80 min-h-52 overflow-auto rounded-md bg-background p-4 font-mono text-xs leading-relaxed text-secondary-foreground",
						children: latest ? `$ ${latest.command}\n\n${latest.output}` : "No commands yet. Output from the phone appears here."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "flex flex-col gap-2 sm:flex-row",
						onSubmit: (event) => {
							event.preventDefault();
							if (!command.trim()) return;
							run.mutate(command.trim());
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: command,
							onChange: (e) => setCommand(e.target.value),
							className: "font-mono",
							spellCheck: false,
							autoComplete: "off",
							"aria-label": "Shell command"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: run.isPending,
							className: "sm:w-32",
							children: run.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : "Run"
						})]
					}),
					history.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: history.slice(0, 6).map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "max-w-full truncate rounded-full bg-muted px-3 py-1 text-xs text-muted-foreground hover:text-foreground",
							onClick: () => setCommand(entry.command),
							children: entry.command
						}, entry.id))
					}) : null
				]
			})]
		})
	});
}
function FilesPanel({ creds }) {
	const cwd = useOmegaStore((s) => s.cwd);
	const setCwd = useOmegaStore((s) => s.setCwd);
	const [path, setPath] = (0, import_react.useState)(cwd);
	const [listing, setListing] = (0, import_react.useState)("");
	const [filePath, setFilePath] = (0, import_react.useState)("");
	const [fileBody, setFileBody] = (0, import_react.useState)("");
	const list = useMutation({
		mutationFn: (target) => callMcpTool({ data: {
			...creds,
			name: "termux_exec",
			args: {
				command: `ls -la -- ${JSON.stringify(target)}`,
				timeout: 20
			},
			timeoutMs: 3e4
		} }),
		onSuccess: (result, target) => {
			setListing(result.text);
			setCwd(target);
		},
		onError: (error) => toast.error(error instanceof Error ? error.message : "List failed")
	});
	const read = useMutation({
		mutationFn: (target) => callMcpTool({ data: {
			...creds,
			name: "read_file",
			args: { path: target },
			timeoutMs: 25e3
		} }),
		onSuccess: (result) => setFileBody(result.text),
		onError: (error) => toast.error(error instanceof Error ? error.message : "Read failed")
	});
	const write = useMutation({
		mutationFn: () => callMcpTool({ data: {
			...creds,
			name: "write_file",
			args: {
				path: filePath,
				content: fileBody
			},
			timeoutMs: 25e3
		} }),
		onSuccess: () => toast.success("Wrote file"),
		onError: (error) => toast.error(error instanceof Error ? error.message : "Write failed")
	});
	(0, import_react.useEffect)(() => {
		if (!listing) list.mutate(path);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "rounded-xl p-1",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
					className: "flex items-center gap-2 text-base",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Folder, { className: "size-4" }), "Directory"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Lists through the Termux shell." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "flex flex-col gap-2 sm:flex-row",
						onSubmit: (event) => {
							event.preventDefault();
							list.mutate(path || ".");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: path,
							onChange: (e) => setPath(e.target.value),
							className: "font-mono",
							spellCheck: false
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: list.isPending,
							className: "sm:w-28",
							children: list.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : "List"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "max-h-80 overflow-auto rounded-md bg-background p-4 font-mono text-xs leading-relaxed",
						children: list.isPending ? "Listing…" : listing || "Empty listing"
					})]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "rounded-xl p-1",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "text-base",
					children: "File"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "read_file / write_file on the phone." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: filePath,
								onChange: (e) => setFilePath(e.target.value),
								placeholder: "~/omega_mcp_bridge.py",
								className: "font-mono",
								spellCheck: false
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "secondary",
								disabled: !filePath || read.isPending,
								onClick: () => read.mutate(filePath),
								className: "sm:w-28",
								children: read.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : "Read"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: fileBody,
							onChange: (e) => setFileBody(e.target.value),
							className: "min-h-48 font-mono text-xs"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							disabled: !filePath || write.isPending,
							onClick: () => write.mutate(),
							children: write.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : "Write"
						})
					]
				})]
			})
		})]
	});
}
function NetworkPanel({ creds, battery }) {
	const [snapshot, setSnapshot] = (0, import_react.useState)("");
	const snap = useMutation({
		mutationFn: () => callMcpTool({ data: {
			...creds,
			name: "network_snapshot",
			timeoutMs: 25e3
		} }),
		onSuccess: (result) => setSnapshot(result.text),
		onError: (error) => toast.error(error instanceof Error ? error.message : "Snapshot failed")
	});
	(0, import_react.useEffect)(() => {
		snap.mutate();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-[1fr_18rem]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "rounded-xl p-1",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
					className: "flex-row items-center justify-between space-y-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
						className: "flex items-center gap-2 text-base",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wifi, { className: "size-4" }), "network_snapshot"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Interfaces, DNS, routes, listeners." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						size: "sm",
						onClick: () => snap.mutate(),
						disabled: snap.isPending,
						children: snap.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : "Refresh"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "max-h-96 overflow-auto rounded-md bg-background p-4 font-mono text-xs leading-relaxed",
					children: snap.isPending && !snapshot ? "Collecting snapshot" : snapshot || "Collecting snapshot"
				}) })]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "rounded-xl p-1",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-wide text-muted-foreground",
					children: "Device"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
					className: "mt-4 space-y-3 text-sm",
					children: [
						["Health", battery?.health ?? null],
						["Status", battery?.status ?? null],
						["Plugged", battery?.plugged ?? null],
						["Temp", battery?.temperature != null ? `${battery.temperature} C` : null],
						["Voltage", battery?.voltage != null ? `${battery.voltage} mV` : null]
					].map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted-foreground",
							children: label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-mono text-xs tabular-nums",
							children: value ?? "—"
						})]
					}, label))
				})]
			})
		})]
	});
}
function ToolsPanel({ creds, tools }) {
	const [query, setQuery] = (0, import_react.useState)("");
	const [searchOut, setSearchOut] = (0, import_react.useState)("");
	const [clip, setClip] = (0, import_react.useState)("");
	const [openclaw, setOpenclaw] = (0, import_react.useState)("");
	const connectors = useQuery({
		queryKey: [
			"mcp-connectors",
			creds.url,
			creds.apiKey
		],
		queryFn: async () => {
			return parseConnectors((await callMcpTool({ data: {
				...creds,
				name: "connector_health",
				timeoutMs: 2e4
			} })).text);
		}
	});
	const search = useMutation({
		mutationFn: (q) => callMcpTool({ data: {
			...creds,
			name: "web_search",
			args: { query: q },
			timeoutMs: 4e4
		} }),
		onSuccess: (result) => setSearchOut(result.text),
		onError: (error) => toast.error(error instanceof Error ? error.message : "Search failed")
	});
	const clipboard = useMutation({
		mutationFn: async (mode) => {
			if (mode === "get") return callMcpTool({ data: {
				...creds,
				name: "clipboard_get",
				timeoutMs: 15e3
			} });
			return callMcpTool({ data: {
				...creds,
				name: "clipboard_set",
				args: { text: clip },
				timeoutMs: 15e3
			} });
		},
		onSuccess: (result, mode) => {
			if (mode === "get") setClip(result.text);
			else toast.success("Clipboard updated");
		}
	});
	const hands = useMutation({
		mutationFn: () => callMcpTool({ data: {
			...creds,
			name: "openclaw_hands",
			args: { action: "status" },
			timeoutMs: 2e4
		} }),
		onSuccess: (result) => setOpenclaw(result.text),
		onError: (error) => toast.error(error instanceof Error ? error.message : "OpenClaw failed")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "rounded-xl p-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Connectors"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-2 sm:grid-cols-3",
						children: [(connectors.data ?? []).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md bg-muted px-3 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium",
									children: item.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: item.available ? "live" : "mute",
									children: item.status
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: item.detail
							})]
						}, item.name)), connectors.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "Reading connector health"
						}) : null]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "rounded-xl p-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
							className: "text-base",
							children: "web_search"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Runs through the OMEGA web connector." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								className: "flex flex-col gap-2 sm:flex-row",
								onSubmit: (event) => {
									event.preventDefault();
									if (query.trim()) search.mutate(query.trim());
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: query,
									onChange: (e) => setQuery(e.target.value)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									disabled: search.isPending,
									className: "sm:w-28",
									children: search.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : "Search"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "max-h-64 overflow-auto rounded-md bg-background p-4 font-mono text-xs",
								children: searchOut || "Results appear here"
							})]
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "rounded-xl p-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
							className: "text-base",
							children: "Clipboard / OpenClaw"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Phone clipboard and Hands status." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									value: clip,
									onChange: (e) => setClip(e.target.value),
									className: "min-h-24",
									placeholder: "Clipboard text"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											variant: "secondary",
											onClick: () => clipboard.mutate("get"),
											disabled: clipboard.isPending,
											children: "Read clipboard"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											variant: "outline",
											onClick: () => clipboard.mutate("set"),
											disabled: clipboard.isPending || !clip,
											children: "Set clipboard"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											variant: "outline",
											onClick: () => hands.mutate(),
											disabled: hands.isPending,
											children: "OpenClaw status"
										})
									]
								}),
								openclaw ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
									className: "max-h-40 overflow-auto rounded-md bg-background p-4 font-mono text-xs",
									children: openclaw
								}) : null
							]
						})]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "rounded-xl p-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Advertised tools"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 divide-y divide-border",
						children: tools.map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start justify-between gap-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-sm",
									children: tool.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: tool.description
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "mt-0.5 size-4 shrink-0 text-muted-foreground" })]
						}, tool.name))
					})]
				})
			})
		]
	});
}
function Home() {
	const { join } = Route.useSearch();
	const [client] = (0, import_react.useState)(() => new QueryClient({ defaultOptions: { queries: {
		retry: 1,
		refetchOnWindowFocus: false
	} } }));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OmegaConsole, { joinKey: join })
	});
}
//#endregion
export { Home as component };
