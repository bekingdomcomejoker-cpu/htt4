import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as object, c as union, i as number, n as boolean, o as record, s as string, t as _null } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/actions-CGfWRKMo.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var DENY = [
	/rm\s+-rf\s+\/(\s|$)/i,
	/rm\s+-rf\s+--no-preserve-root/i,
	/mkfs\./i,
	/:\(\)\s*\{\s*:\s*\|\s*:\s*&\s*\}\s*;/,
	/dd\s+if=.*of=\s*\/dev\//i,
	/chmod\s+-R\s+777\s+\//,
	/>\s*\/dev\/[sh]d/
];
function assertSafeCommand(command) {
	const trimmed = command.trim();
	if (!trimmed) throw new Error("Command is empty.");
	for (const pattern of DENY) if (pattern.test(trimmed)) throw new Error("That command is blocked by the console sandbox.");
	return trimmed;
}
var sessions = /* @__PURE__ */ new Map();
var SESSION_TTL_MS = 48e4;
function sessionKey(url, apiKey) {
	return `${url}::${apiKey.slice(0, 12)}`;
}
function assertPublicHttps(raw) {
	let parsed;
	try {
		parsed = new URL(raw);
	} catch {
		throw new Error("MCP URL is not valid.");
	}
	if (parsed.protocol !== "https:") throw new Error("MCP URL must be https.");
	const host = parsed.hostname.toLowerCase();
	if (host === "localhost" || host.endsWith(".local") || host === "127.0.0.1" || host === "::1" || host.startsWith("10.") || host.startsWith("192.168.") || host.startsWith("169.254.") || /^172\.(1[6-9]|2\d|3[0-1])\./.test(host)) throw new Error("MCP URL cannot target a private host.");
	return parsed.origin;
}
function asRecord(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return null;
	return value;
}
function extractText(payload) {
	if (payload == null) return "";
	if (typeof payload === "string") return payload;
	const record = asRecord(payload);
	if (!record) return String(payload);
	const error = asRecord(record.error);
	if (error?.message) return String(error.message);
	const result = asRecord(record.result);
	if (result && Array.isArray(result.content)) return result.content.map((part) => part.text || "").filter(Boolean).join("\n");
	if (result) try {
		return JSON.stringify(record.result, null, 2);
	} catch {
		return String(record.result);
	}
	try {
		return JSON.stringify(payload, null, 2);
	} catch {
		return String(payload);
	}
}
function isErrorPayload(payload) {
	const record = asRecord(payload);
	if (!record) return false;
	if (record.error) return true;
	const result = asRecord(record.result);
	return Boolean(result && result.isError === true);
}
async function parseBody(res) {
	const ctype = res.headers.get("content-type") || "";
	const text = await res.text();
	if (!text) return null;
	if (ctype.includes("text/event-stream")) {
		const events = text.split("\n");
		for (const line of events) {
			if (!line.startsWith("data:")) continue;
			const data = line.slice(5).trim();
			if (!data || data === "[DONE]") continue;
			try {
				return JSON.parse(data);
			} catch {
				return data;
			}
		}
		throw new Error("Empty MCP stream.");
	}
	try {
		return JSON.parse(text);
	} catch {
		return text;
	}
}
async function mcpFetch(origin, apiKey, body, sessionId, timeoutMs) {
	const controller = new AbortController();
	const timer = setTimeout(() => controller.abort(), timeoutMs);
	try {
		const headers = {
			"Content-Type": "application/json",
			Accept: "application/json, text/event-stream",
			"X-API-Key": apiKey,
			"ngrok-skip-browser-warning": "true"
		};
		if (sessionId) headers["Mcp-Session-Id"] = sessionId;
		const res = await fetch(`${origin}/mcp`, {
			method: "POST",
			headers,
			body: JSON.stringify(body),
			signal: controller.signal
		});
		const nextSession = res.headers.get("mcp-session-id") || sessionId;
		const payload = await parseBody(res);
		return {
			status: res.status,
			sessionId: nextSession,
			payload
		};
	} finally {
		clearTimeout(timer);
	}
}
async function ensureSession(origin, apiKey, timeoutMs) {
	const key = sessionKey(origin, apiKey);
	const cached = sessions.get(key);
	if (cached && Date.now() - cached.initializedAt < SESSION_TTL_MS) return cached.sessionId;
	const init = await mcpFetch(origin, apiKey, {
		jsonrpc: "2.0",
		id: 1,
		method: "initialize",
		params: {
			protocolVersion: "2025-03-26",
			capabilities: {},
			clientInfo: {
				name: "omega-pool-console",
				version: "2.4.0"
			}
		}
	}, null, timeoutMs);
	if (init.status === 401) throw new Error("Unauthorized — check the X-API-Key.");
	if (init.status >= 400 || !init.sessionId) throw new Error(`MCP initialize failed (${init.status}): ${extractText(init.payload) || "no session"}`);
	await mcpFetch(origin, apiKey, {
		jsonrpc: "2.0",
		method: "notifications/initialized"
	}, init.sessionId, Math.min(timeoutMs, 8e3));
	sessions.set(key, {
		sessionId: init.sessionId,
		initializedAt: Date.now()
	});
	return init.sessionId;
}
async function probeHealth(url) {
	const origin = assertPublicHttps(url);
	const controller = new AbortController();
	const timer = setTimeout(() => controller.abort(), 8e3);
	try {
		const res = await fetch(`${origin}/health`, {
			headers: { "ngrok-skip-browser-warning": "true" },
			signal: controller.signal
		});
		const text = await res.text();
		let service = "";
		let transport = "";
		let port = 0;
		try {
			const parsed = JSON.parse(text);
			service = String(parsed.service ?? "");
			transport = String(parsed.transport ?? "");
			port = Number(parsed.port ?? 0) || 0;
		} catch {
			service = text.slice(0, 120);
		}
		return {
			ok: res.ok,
			status: res.status,
			service,
			transport,
			port,
			error: ""
		};
	} catch (error) {
		return {
			ok: false,
			status: 0,
			service: "",
			transport: "",
			port: 0,
			error: error instanceof Error ? error.message : "Health probe failed"
		};
	} finally {
		clearTimeout(timer);
	}
}
async function callMcp(options) {
	const origin = assertPublicHttps(options.url);
	const apiKey = options.apiKey.trim();
	if (apiKey.length < 8) throw new Error("API key looks too short.");
	const timeoutMs = options.timeoutMs ?? 25e3;
	const invoke = async (sessionId) => mcpFetch(origin, apiKey, {
		jsonrpc: "2.0",
		id: Date.now() % 1e6,
		method: options.method,
		params: options.params
	}, sessionId, timeoutMs);
	let sessionId = await ensureSession(origin, apiKey, timeoutMs);
	let response = await invoke(sessionId);
	if (response.status === 401) throw new Error("Unauthorized — check the X-API-Key.");
	if (response.status === 404 || response.status === 400) {
		sessions.delete(sessionKey(origin, apiKey));
		sessionId = await ensureSession(origin, apiKey, timeoutMs);
		response = await invoke(sessionId);
	}
	return {
		ok: response.status < 400 && !isErrorPayload(response.payload),
		status: response.status,
		sessionId: response.sessionId,
		text: extractText(response.payload)
	};
}
async function callTool(options) {
	if (options.name === "termux_exec") assertSafeCommand(String(options.args?.command ?? ""));
	return callMcp({
		url: options.url,
		apiKey: options.apiKey,
		method: "tools/call",
		params: {
			name: options.name,
			arguments: options.args ?? {}
		},
		timeoutMs: options.timeoutMs
	});
}
async function listTools(options) {
	const result = await callMcp({
		url: options.url,
		apiKey: options.apiKey,
		method: "tools/list",
		timeoutMs: 2e4
	});
	try {
		return { tools: (JSON.parse(result.text).tools ?? []).map((tool) => ({
			name: tool.name || "unknown",
			description: tool.description || ""
		})) };
	} catch {
		return { tools: [] };
	}
}
var creds = {
	url: string().url(),
	apiKey: string().min(8)
};
var jsonScalar = union([
	string(),
	number(),
	boolean(),
	_null()
]);
var probeMcpHealth_createServerFn_handler = createServerRpc({
	id: "97f5bb22daad0d8fbbdc08f9fefc383669f827ef8e7e8f92e7a3097af065da18",
	name: "probeMcpHealth",
	filename: "src/lib/mcp/actions.ts"
}, (opts) => probeMcpHealth.__executeServer(opts));
var probeMcpHealth = createServerFn({ method: "POST" }).validator(object({ url: string().url() })).handler(probeMcpHealth_createServerFn_handler, async ({ data }) => probeHealth(data.url));
var listMcpTools_createServerFn_handler = createServerRpc({
	id: "fa8e5cfdbb9f0d98de7951d42c5d501396053ad659094f9b193013667d56c85c",
	name: "listMcpTools",
	filename: "src/lib/mcp/actions.ts"
}, (opts) => listMcpTools.__executeServer(opts));
var listMcpTools = createServerFn({ method: "POST" }).validator(object(creds)).handler(listMcpTools_createServerFn_handler, async ({ data }) => listTools(data));
var callMcpTool_createServerFn_handler = createServerRpc({
	id: "1799d2095a177b536c877de2f355dbc1ef57bebf9d22ee3ff19363bca7db8ff5",
	name: "callMcpTool",
	filename: "src/lib/mcp/actions.ts"
}, (opts) => callMcpTool.__executeServer(opts));
var callMcpTool = createServerFn({ method: "POST" }).validator(object({
	...creds,
	name: string().min(1),
	args: record(string(), jsonScalar).optional(),
	timeoutMs: number().int().min(1e3).max(12e4).optional()
})).handler(callMcpTool_createServerFn_handler, async ({ data }) => callTool({
	url: data.url,
	apiKey: data.apiKey,
	name: data.name,
	args: data.args,
	timeoutMs: data.timeoutMs
}));
//#endregion
export { callMcpTool_createServerFn_handler, listMcpTools_createServerFn_handler, probeMcpHealth_createServerFn_handler };
