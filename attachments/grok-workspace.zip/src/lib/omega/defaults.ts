export const DEFAULT_MCP_URL =
  "https://direction-egotistic-citric.ngrok-free.dev";

export const APP_NAME = "OMEGA Pool";
